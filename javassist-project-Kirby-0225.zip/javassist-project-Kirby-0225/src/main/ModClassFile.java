package main;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.CtMethod;
import javassist.Loader;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.NewExpr;

public class ModClassFile {
	static String WORK_DIR = System.getProperty("user.dir");
	static String OUTPUT_DIR = WORK_DIR + File.separator + "output";
	static String _L_ = System.lineSeparator();
	private ClassPool pool;
	static String className;
	static String methodName;
	static int fieldNum;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] list;
		ArrayList<String> methodAlreadyModded = new ArrayList<String>();

		do {
			System.out.println("Please enter a class name, a method name, and the number of method parameters to be analyzed and displayed.\n"
					+ "(e.g. ComponentApp, foo, 2 or ServiceApp, bar, 10)\n" + "Key \\\"q\\\" to quit.");
			String input = sc.nextLine();
			list = input.split(",");
			for (int i = 0; i < list.length; i++) {
				list[i] = list[i].trim();
				if (list[i].equals("q")) {
					System.out.println("You have quit the program.");
					sc.close();
					System.exit(0);
				}
			}
			System.out.println("");

			if (list.length != 3) {
				System.out.println("[WRN] Invalid Input size!!\n" + "");
			}
			else if (methodAlreadyModded.contains(list[1])) {
				System.out.println("[WRN] Invalid input method!!\n" + "");
			}
			else if (list[1].equals("privateComp") || list[1].equals("privateServ")) {
				System.out.println("[WRN] Cannot modify a private method!!\n" + "");
			}
			else if (list[0].equals("ComponentApp") && !list[1].equals("foo")) {
				System.out.println("[WRN] Invalid input class!!\n" + "");
			}
			else if (list[0].equals("ServiceApp") && !list[1].equals("bar")) {
				System.out.println("[WRN] Invalid input class!!\n" + "");
			}
			else {
				className = "target." + list[0];
				methodName = list[1];
				fieldNum = Integer.parseInt(list[2]);

				try {
					ClassPool pool = ClassPool.getDefault();
					CtClass cc = pool.get(className);
					
					for(int i = 1; i <= fieldNum; i++) {
						CtMethod ctMeth = cc.getDeclaredMethod(methodName);
						
						String printBlock = "{ " + "System.out.println(\"[Inserted] " + className + "." + methodName +"'s parm " + i
								+ ": \" + $" + i + "); " + "}";

						ctMeth.insertBefore(printBlock);
					}
					
					Loader loader = new Loader(pool);
					Class<?> c = loader.loadClass(className);
					Method m1 = c.getDeclaredMethod("main", new Class[] { String[].class });
					m1.invoke(null, new Object[] { list });
					cc.writeFile(OUTPUT_DIR);
					
					methodAlreadyModded.add(list[1]);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			for (int i = 0; i < list.length; i++) {
				list[i] = null;
			}
		} while (true);
	}

	public ModClassFile() throws NotFoundException {
		pool = new ClassPool();
		pool.insertClassPath(new ClassClassPath(new java.lang.Object().getClass()));
	}
}